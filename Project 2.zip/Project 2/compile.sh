make 
clear
./run
rm run
rm adventure.o
rm items.o
rm keyword.o
rm room.o
